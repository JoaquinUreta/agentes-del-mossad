import os
import tkinter as tk
from tkinter import SUNKEN, ttk
import platform
from tkinter import messagebox
from tkinter import filedialog
from Renderizador import RenderizadorParser
from BarraBusqueda import BarraBusqueda  

class Ventana():
    def __init__(self):
        pass

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

main = tk.Tk()
main.title("GO FILE EXPLORER")
main.config(bg="#E4E2E2")

sistema = platform.system()

margen = 10
main.update_idletasks()

ancho_monitor = main.winfo_screenwidth()
alto_monitor  = main.winfo_screenheight()
ancho = ancho_monitor - 2 * margen
alto  = alto_monitor  - 2 * margen

if sistema == "Windows":
    main.state("zoomed")
else:
    main.geometry(f"{ancho}x{alto}+{margen}+{margen}")

main.minsize(600, 400)
main.resizable(True, True)

# ===================== Style =====================
style = ttk.Style(main)
style.theme_use("clam")
# ===================== GRID PRINCIPAL =====================
main.columnconfigure(0, weight=1)
main.rowconfigure(1, weight=1)

# ===================== CONTENT =====================
content_frame = tk.Frame(main, bg="#EDECEC")
content_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)

content_frame.columnconfigure(0, weight=0)
content_frame.columnconfigure(1, weight=1)
content_frame.rowconfigure(0, weight=1)

# ===================== SIDEBAR =====================
sidebar = tk.Frame(content_frame, bg="#EDECEC", width=150)
sidebar.grid(row=0, column=0, sticky="ns", padx=(0, 10))
sidebar.grid_propagate(False)

sidebar.rowconfigure(0, weight=1)
sidebar.rowconfigure(1, weight=0)

style.configure("entry1.TEntry", fieldbackground="#fff", foreground="#000")
entry1 = ttk.Entry(sidebar, style="entry1.TEntry")
entry1.grid(row=1, column=0, sticky="ew", padx=5, pady=5)

# ===================== MAIN AREA =====================
main_area = tk.Frame(content_frame, bg="#FFFFFF")
main_area.grid(row=0, column=1, sticky="nsew")

area_contenido = tk.Text(main_area)
area_contenido.pack(expand=True, fill="both", padx=20, pady=10)

# ===================== BOTTOM BAR =====================
bottom_bar = tk.Frame(main_area)
bottom_bar.pack(side="bottom", anchor="e", padx=10, pady=10)

# ===================== Boton Editar Archivo =====================
def Editar_Archivo():
    respuesta = messagebox.askyesno("Editar", "¿Deseas editar este documento?")
    if respuesta:
        area_contenido.config(state="normal")
    else:
        area_contenido.config(state="disabled")

boton_editar_archivo = ttk.Button(bottom_bar, text="Editar Archivo", command=Editar_Archivo)
boton_editar_archivo.config(state="disabled")
boton_editar_archivo.pack(side="right", padx=5)

# ===================== Boton Guardar Cambios =====================
def guardar_archivo(ruta_destino=None):
    ruta = ruta_destino or barra.get_ruta_actual()
    if not ruta:
        messagebox.showwarning("Atención", "No hay un archivo abierto")
        return
    try:
        area_contenido.config(state="normal")
        contenido = area_contenido.get("1.0", "end-1c")
        area_contenido.config(state="disabled")
        with open(ruta, "w", encoding="utf-8") as archivo:
            archivo.write(contenido)
        messagebox.showinfo("Éxito", "Archivo guardado correctamente")
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo guardar:\n{e}")

boton_guardar_archivo = ttk.Button(bottom_bar, text="Guardar Cambios", command=guardar_archivo)
boton_guardar_archivo.config(state="disabled")
boton_guardar_archivo.pack(side="right", padx=5)

# ===================== Guardar Como Nuevo =====================
def guardar_como():
    ruta = filedialog.asksaveasfilename(
        defaultextension=".*",
        filetypes=[("Todos los archivos", "*.*")]
    )
    if not ruta:
        return
    guardar_archivo(ruta)

boton_guardar_comonuevo = ttk.Button(bottom_bar, text="Guardar Como Nuevo", command=guardar_como)
boton_guardar_comonuevo.config(state="disabled")
boton_guardar_comonuevo.pack(side="right", padx=5)

# ===================== BARRA DE BÚSQUEDA =====================
barra = BarraBusqueda(
    parent=main,
    style=style,
    area_contenido=area_contenido,
    botones_habilitar=[boton_guardar_archivo, boton_guardar_comonuevo],
    boton_editar=boton_editar_archivo
)
barra.top_frame.grid(row=0, column=0, sticky="ew", padx=10, pady=5)
barra.estado_label.grid(row=3, column=0, sticky="ew")
barra.progress.grid(row=4, column=0, padx=5, pady=5, sticky="ew")

# ===================== MODOS OSCURO / CLARO =====================
def Modo_Oscuro():
    main.config(bg="#2E2E2E")
    content_frame.config(bg="#3C3C3C")
    sidebar.config(bg="#444444")
    main_area.config(bg="#3C3C3C")
    area_contenido.config(bg="#1E1E1E", fg="#EEEEEE")
    bottom_bar.config(bg="#3C3C3C")
    barra.actualizar_tema(
        bg_frame="#3C3C3C",
        bg_entry="#555555", fg_entry="#FFFFFF",
        bg_boton="#555555", fg_boton="#FFFFFF",
        active_bg="#666666"
    )
    for w in [menu_contextual, menu_btn]:
        try:
            w.config(bg="#3C3C3C", fg="#FFFFFF")
        except Exception:
            pass

def Modo_Claro():
    main.config(bg="#E4E2E2")
    content_frame.config(bg="#E4E2E2")
    sidebar.config(bg="#EDECEC")
    main_area.config(bg="#E4E2E2")
    area_contenido.config(bg="#FFFFFF", fg="#000000")
    bottom_bar.config(bg="#E4E2E2")
    barra.actualizar_tema(
        bg_frame="#E4E2E2",
        bg_entry="#FFFFFF", fg_entry="#000000",
        bg_boton="#FFFFFF", fg_boton="#000000",
        active_bg="#E4E2E2"
    )
    for w in [menu_contextual, menu_btn]:
        try:
            w.config(bg="#E4E2E2", fg="#000000")
        except Exception:
            pass

menu_btn = ttk.Menubutton(bottom_bar, text="Ajustes", style="Custom.TMenubutton")
menu_btn.pack(side="right", padx=5)

menu_contextual = tk.Menu(menu_btn, tearoff=0)
menu_contextual.add_command(label="Modo Oscuro", command=Modo_Oscuro)
menu_contextual.add_command(label="Modo Claro",  command=Modo_Claro)
menu_btn["menu"] = menu_contextual

# ===================== CIERRE =====================
def cerrado():
    if messagebox.askokcancel("Salir", "¿Seguro que quieres cerrar el navegador?"):
        main.destroy()

main.protocol("WM_DELETE_WINDOW", cerrado)
main.mainloop()